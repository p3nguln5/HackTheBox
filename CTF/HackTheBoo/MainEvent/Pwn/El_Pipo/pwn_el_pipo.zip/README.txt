In this challenge, you'll be provided with the binary file that runs on the server's back end.

[*] Your task is to reverse-engineer the binary and identify the vulnerability.
[!] Do not attempt to connect via netcat; a web page is provided for interaction :)
[*] The input you submit is passed directly to the binary.
[!] If a few words don't get the job done, consider trying a bit more...
